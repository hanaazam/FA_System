<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }

 $Venue_name = $_POST['venue_name'];
 $Venue_date = $_POST['venue_date'];
 
 $sql = "INSERT INTO venue (Venue_name, Venue_date) VALUES ('$Venue_name', '$Venue_date')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else
 {
	 echo '<script type="text/javascript">
                      alert("Successfully Added!");
                         location="home.php";
                           </script>';
 }
 

?>