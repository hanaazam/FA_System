<?php
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>

body {
    background-image: url();
    background-color: white;
}
th {
    text-align: center;
}
tr {
     height: 30px;
}
td {
    padding-top: 5px;
    padding-left: 20px; 
    padding-bottom: 5px;    
    height: 20px;
}

</style>
</head>
<body><br>
<div class="container">

<body>
    <?php
     echo "<tr>
            <td>";
               // your database connection
               $host       = "localhost"; 
               $username   = "root"; 
               $password   = "";
               $database   = "fa_db"; 
               
               // select database
               $conn = mysqli_connect($host,$username,$password,$database) or die(mysqli_error($conn)); 

                    $query = ("SELECT * FROM examiner");
                    $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
                    echo "<div class='container'><table width='' class='table table-bordered' border='1' >
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Action</th>
                            </tr>";
                        while($row = mysqli_fetch_array($result))
                        {
                        echo "<tr>";
                        echo "<td>" . $row['examiner_name'] . "</td>";
                        echo "<td>" . $row['examiner_email'] . "</td>";
                        echo "<td>" . $row['examiner_date'] . "</td>";
                        echo "<td>" . $row['examiner_time'] . "</td>";
                        echo "<td><form class='form-horizontal' method='post' action='examinerlist.php'>
                        <input name='examiner_id' type='hidden' value='".$row['examiner_id']."';>
                        <input type='submit' class='btn btn-danger' name='delete' value='Delete'>
                        </form></td>";
                        echo "</tr>";
                        }
                    echo "</table>";

            echo "</td>           
        </tr>";

       // delete record
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
       
    if(isset($_POST['examiner_id']))
    {
    $examiner_id = mysqli_real_escape_string($conn,$_POST['examiner_id']);
    $sql = mysqli_query($conn,"DELETE FROM examiner WHERE examiner_id='$examiner_id'");
    if(!$sql)
    {
        echo ("Could not delete rows" .mysqli_error($conn));
    }else{
       echo '<script type="text/javascript">
                      alert("Course Successfully Deleted");
                         location="list.php";
                           </script>';
    }
    
    }
    }

    ?>
</fieldset>
</form>
</div>
</div>
</div>
</div>
    </body>
    </html>
    
<?php
   include_once("footer.php");

?>
