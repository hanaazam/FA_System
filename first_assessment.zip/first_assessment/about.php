<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "header.php";
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>
body {
	background-color: white;
}
</style>
</head>
<body>
<br><div class="container">
	
  <div class="row">
    <div class="col-lg-14">
		<div class="jumbotron">
            <h2><b> POSTGRADUATE STUDENTS FIRST ASSESSMENT MANAGEMENT SYSTEM @ FIRST ASSESSMENT (FA) </b> </h2>
		<h3>First Assessment (FA) is A Web-Based management system of School Of Computing for easily access by users in handling the First Assessment Management System for Postgraduate students in UTM</h3>
		<form class="form-horizontal" method= "post" action = "addtimetable.php">
			<fieldset>
