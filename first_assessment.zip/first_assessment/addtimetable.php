<?php 

$con = mysqli_connect ('localhost', 'root', '', 'fa_db');
 if (!$con)
 {
	 echo 'not connected to server';
 }
mysqli_select_db($con, 'fa_db') or die(mysqli_error($con));
	 

 function getPosts()
   {
    $posts = array();
    $posts[0] = $_POST['student_name'];
    $posts[1] = $_POST['student_title'];
    $posts[2] = $_POST['supervisor_name'];
    $posts[3] = $_POST['examiner_name'];
	  $posts[4] = $_POST['chairperson_name'];
	  $posts[5] = $_POST['venue_name'];
    return $posts;
}

if (isset($_POST['insert'])) {
	
	$data = getPosts();

	$existing_Query ="SELECT * FROM `addtimetable` WHERE `student_name`='$data[0]' OR `student_title`='$data[1]' OR `supervisor_name`='$data[2]' OR `examiner_name`='$data[3]' OR `chairperson_name`='$data[4]' OR `venue_name`='$data[5]'";
	$existing_Result = mysqli_query($con, $existing_Query);
	if(0 < mysqli_num_rows ($existing_Result)){
		echo '<script type="text/javascript">
                      alert("Already insert to time table");
                         window.location="home.php";
                           </script>';
	} else {
    $insert_Query = "INSERT INTO 'addtimetable'(`supervisor_name`, `examiner_name`, `student_name`, `chairperson_name`, `student_title`, `venue_name`) VALUES ('$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]', '$data[5]')";
    $insert_Result = mysqli_query($con, $insert_Query);
   
    if  ($insert_Result) {
      echo "<script type='text/javascript'>
                      alert('Successfully Added');
                         window.location='tablelist.php';
                           </script>";
    } else {
      echo "<script type='text/javascript'>
                      alert('Data not inserted!');
                         window.location='home.php';
                           </script>";
    }
  }

  
  }
?>