<?php
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>

body {
    background-image: url();
    background-color: white;
}
th {
    text-align: center;
}
tr {
     height: 30px;
}
td {
    padding-top: 5px;
    padding-left: 20px; 
    padding-bottom: 5px;    
    height: 20px;
}

</style>
</head>
<body><br>
<div class="container">


<body>
    <?php
     echo "<tr>
            <td>";
               // your database connection
               $host       = "localhost"; 
               $username   = "root"; 
               $password   = "";
               $database   = "fa_db"; 
               
               // select database
               $conn = mysqli_connect($host,$username,$password,$database) or die(mysqli_error($conn)); 

                    $query = ("SELECT * FROM student");
                    $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
                    echo "<div class='container'><table width='' class='table table-bordered' border='1' >
                            <tr>
                                <th>Student</th>
                                <th>Matric No</th>
                                <th>Email</th>
                                <th>Title</th>
                                <th>Supervisor</th>
                                <th>Venue</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Grade</th>
                                <th>Action</th>
                            </tr>";
                        while($row = mysqli_fetch_array($result))
                        {
                        echo "<tr>";
                        echo "<td>" . $row['student_name'] . "</td>";
                        echo "<td>" . $row['student_matric'] . "</td>";
                        echo "<td>" . $row['student_email'] . "</td>";
                        echo "<td>" . $row['student_title'] . "</td>";
                        echo "<td>" . $row['student_supervisor'] . "</td>";
                        echo "<td>" . $row['student_venue'] . "</td>";
                        echo "<td>" . $row['student_date'] . "</td>";
                        echo "<td>" . $row['student_time'] . "</td>";
                        echo "<td>" . $row['student_grade'] . "</td>";
                        echo "<td><form class='form-horizontal' method='post' action='studentlist.php'>
                        <input name='student_id' type='hidden' value='".$row['student_id']."';>
                        <input type='submit' class='btn btn-danger' name='delete' value='Delete'>
                        </form></td>";
                        echo "</tr>";
                        }
                    echo "</table>";

            echo "</td>           
        </tr>";

       // delete record
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        
    if(isset($_POST['student_id']))
    {
    $student_id = mysqli_real_escape_string($conn,$_POST['student_id']);
    $sql = mysqli_query($conn,"DELETE FROM student WHERE student_id='$student_id'");
    if(!$sql)
    {
        echo ("Could not delete rows" .mysqli_error($conn));
    }else{
      echo '<script type="text/javascript">
                      alert("Successfully Deleted");
                         location="list.php";
                           </script>';
    }
    
    }
    }

    ?>
</fieldset>
</form>
</div>
</div>
</div>
</div>
    </body>
    </html>
    
<?php
   include_once("footer.php");

?>
