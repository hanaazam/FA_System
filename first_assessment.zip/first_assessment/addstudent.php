<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "header.php";
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>
body {
	background-color: white;
}
</style>
</head>
<body>
 
 <br><div class="container"> 
  <div class="row">
    <div class="col-lg-6">
		<div class="jumbotron">
                Student add to the list
				<form class="form-horizontal" method= "POST" action="add_student.php">
				<fieldset>

				<!-- Form Name -->
				<legend>Add Student</legend>

				<!-- Text input1-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studentname">Name</label>  
				  <div class="col-md-5">
				  <input id="studentname" name="studentname" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>

				<!-- Text input2-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studentmatric">Matric No</label>  
				  <div class="col-md-5">
				  <input id="studentmatric" name="studentmatric" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>
                <!--Text input3-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studentemail">Email</label>  
				  <div class="col-md-5">
				  <input id="studentemail" name="studentemail" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>

				<!-- Text input4-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studenttitle">Title</label>  
				  <div class="col-md-5">
				  <input id="studenttitle" name="studenttitle" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>
               <!-- Text input5-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studentsupervisor">Supervisor</label>  
				  <div class="col-md-5">
				  <input id="studentsupervisor" name="studentsupervisor" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>

				<!-- Text input6-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studentvenue">Venue</label>  
				  <div class="col-md-5">
				  <input id="studentvenue" name="studentvenue" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>
				
				<!--Text input7-->
                <div class="form-group">
				  <label class="col-md-4 control-label" for="studentdate">Date</label>  
				  <div class="col-md-5">
				  <input id="studentdate" name="studentdate" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>

				<!-- Text input8-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studenttime">Time</label>  
				  <div class="col-md-5">
				  <input id="studenttime" name="studenttime" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>

				<!-- Text input9-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="studentgrade">Grade</label>  
				  <div class="col-md-5">
				  <input id="studentgrade" name="studentgrade" type="text" placeholder="" class="form-control input-md" required="">
					
				  </div>
				</div>
				

				<!-- Button -->
				<div class="form-group"  align="right">
				  <label class="col-md-4 control-label" for="submit"></label>
				  <div class="col-md-5">
					<input type="submit" id="submit" name="submit" class="btn btn-primary" value="Add Student"></input>
				  </div>
				</div>

				</fieldset>
				</form>
		</div>		
    </div>




<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");
   include_once("navbar.php");
?>