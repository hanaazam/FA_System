<?php

$hostname = "localhost";
$username = "root";
$password ="";
$databaseName = "fa_db";

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
if (!$connect) {
	echo 'no connection';
}


$fa_id = "";
$supervisor_name = "";
$student_name = "";
$chairperson_name = "";
$grade = "";
$venue_name = "";


function getPosts()
{
    $posts = array();
    $posts[0] = $_POST['student'];
    $posts[1] = $_POST['title'];
    $posts[2] = $_POST['supervisor'];
    $posts[3] = $_POST['examiner'];
	$posts[4] = $_POST['chairperson'];
	$posts[5] = $_POST['venue'];
    return $posts;
}


if(isset($_POST['insert']))
{
    $data = getPosts();
	

		$existing_Query = "SELECT * from `fa_data` WHERE `supervisor`='$data[0]' OR `examiner`='$data[1]'
		`student`='$data[2]' OR `chairperson`='$data[3]' OR `grade`='$data[4]' OR `venue`='$data[5]'";
		$existing_Result = mysqli_query($connect, $existing_Query);
		if (0 < mysqli_num_rows($existing_Result)) {
			
			echo '<script type="text/javascript">
                  alert("Duplicate Data! There is already existing schedule at the table. please choose another schedule. thank you");
                   location="insertion.php";
                 </script>';
        } 
		

    $insert_Query = "INSERT INTO `fa_data`(``, 'examiner', `student`, `chairperson`, `grade`, `venue`) VALUES ('$data[0]','$data[1]', '$data[2]', '$data[3]', '$data[4]', '$data[5]')";
    
    try{
        $insert_Result = mysqli_query($connect, $insert_Query);

        if($insert_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {

                echo '<script type="text/javascript">
                      alert("New Schedule Added Successfully");
                         location="tb.php";
                           </script>';
				
            }
			else{
                echo 'Data Not Inserted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Insert '.$ex->getMessage();
    }
}

?>
<?php
   include_once("header.php");
    include_once("navbar.php");
?>

<?php

// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "fa_db";

// connect to mysqli database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysqli select query
$query = "SELECT * FROM `examiner`";

// for method 1

$result1 = mysqli_query($connect, $query);

// for method 2
$query = "SELECT * FROM `supervisor";
$result2 = mysqli_query($connect, $query);

$options = "";

while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[1]</option>";
}

?>
<html>
<head>
<style>

body {
	background-image: url();
	background-color: white;
}
</style>
</head>

<body>
 <div class="content">
		<div class="form">
		<form class="form-horizontal" method="post" action="insertion.php">
			<fieldset>
	        <legend>Add Schedule Here</legend>
			
			 <div class="form-group">
			<label class="col-md-4 control-label" for="supervisor">Supervisor</label> 
			<div class="col-md-5">
		<select id="supervisor" name="supervisor" class="form-control">
            <?php echo $options;?>
        </select>
		</div>
		</div>
		
        <!--Method One-->
        <div class="form-group">
			<label class="col-md-4 control-label" for="Examiner">Course</label> 
			<div class="col-md-5">
		<select  id="examiner" name="examiner"  class="form-control">

            <?php while($row1 = mysqli_fetch_array($result1)):;?>

            <option  value="<?php echo $row1[2];?>"><?php echo $row1[2];?></option>

            <?php endwhile;?>

        </select>
        
        

		</div>		
    </div>
    </body>
</head>
</html>
			
			
			<?php

// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "fa_db";

// connect to mysqli database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysqli select query
$query = "SELECT * FROM `chairperson`";

// for method 1

$result1 = mysqli_query($connect, $query);

// for method 2
$query = "SELECT * FROM `student`";
$result2 = mysqli_query($connect, $query);


$options = "";

while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[2]</option>";
}

?>


<html>
<head>
</head>
<body>


        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>
        
		<!-- Method Two -->
        <div class="form-group">
			<label class="col-md-4 control-label" for="student">Student</label> 
			<div class="col-md-5">
		<select  id="student" name="student"  class="form-control">
            <?php echo $options;?>
        </select>
		</div>
		</div>
		
        

            <?php while($row2 = mysqli_fetch_array($result2)):;?>

            <option value="<?php echo $row2[0];?>"><?php echo $row2[2];?></option>

            <?php endwhile;?>

        </select> 
		<?php

// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "fa_db";

// connect to mysqli database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysqli select query
$query = "SELECT * FROM `chairperson`";

// for method 1

$result1 = mysqli_query($connect, $query);

// for method 2
$query = "SELECT * FROM `chairperson`";
$result2 = mysqli_query($connect, $query);


$options = "";

while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[1]</option>";
}

 
?>



<html>
<head>
</head>
<body>
<meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>
        
		<!-- Method Two -->
        <div class="form-group">
			<label class="col-md-4 control-label" for="chairperson">Chairperson</label> 
			<div class="col-md-5">
		<select  id="chairperson" name="chairperson"  class="form-control">
            <?php echo $options;?>
        </select>
		</div>
		</div>
		
        <!--Method One-->
        
       

            <?php while($row2 = mysqli_fetch_array($result2)):;?>

            <option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
			

            <?php endwhile;?>

        </select>
			

           <?php

// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "fa_db";

// connect to mysqli database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysqli select query
$query = "SELECT * FROM `grade`";

// for method 1

$result1 = mysqli_query($connect, $query);

// for method 2
$query = "SELECT * FROM `grade`";
$result2 = mysqli_query($connect, $query);


$options = "";

while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[1]</option>";
}

 
?>



<html>
<head>
</head>
<body>
<meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>
        
		
		
        <!--Method One-->
        <div class="form-group">
			<label class="col-md-4 control-label" for="grade">Grade</label> 
			<div class="col-md-5">
		<select  id="grade" name="grade" class="form-control">
		  <?php echo $options;?>
       

            <?php while($row2 = mysqli_fetch_array($result2)):;?>

            <option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
			

            <?php endwhile;?>

        </select>
        
		</div>		
    </div>
    </body>
</head>
</html>
        

<?php

// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "fa_db";

// connect to mysqli database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysqli select query
$query = "SELECT * FROM `grade`";

// for method 1

$result1 = mysqli_query($connect, $query);

// for method 2
$query = "SELECT * FROM `grade`";
$result2 = mysqli_query($connect, $query);


$options = "";

while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[2]</option>";
}

?>





        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>
        
		<!-- Method Two -->
        <div class="form-group">
			<label class="col-md-4 control-label" for="venue">End time</label> 
			<div class="col-md-5">
		<select  id="venue" name="venue" class="form-control">
            <?php echo $options;?>
        </select>
		</div>
		</div>
		
       

            <?php while($row2 = mysqli_fetch_array($result2)):;?>

            <option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>

            <?php endwhile;?>

        </select>


            <div>
                <div class="form-group">
			  <label class="col-md-4 control-label" for="add"></label>
			  <div class="col-md-4">
                <input id="button"  class="" type="submit" name="insert" value="Add">
				
				</fieldset>
				</div>
        </form>
		
		
				<div id="field">
		Note: Please fill all the fields. 
		</div>
	</div>
    </body>
	

<?php
$path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");

?>
