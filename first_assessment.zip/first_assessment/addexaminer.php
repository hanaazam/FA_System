<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "header.php";
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>
body {
	background-color: white;
}
</style>
</head>
<body>

<br><div class="container">
	
  <div class="row">
    <div class="col-lg-6">
		<div class="jumbotron">
		Examiner add to the list
		<form class="form-horizontal" method= "post" action = "add_examiner.php">
			<fieldset>

			<!-- Form Name -->
			<legend>Add Examiner</legend>

			
			<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="examinername">Name</label>  
				  <div class="col-md-5">
				  <input id="examinername" name="examinername" type="text" placeholder="" class="form-control input-md" required="">	
				  </div>
				</div>
				
			
			<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="examineremail">Email</label>  
				  <div class="col-md-5">
				  <input id="examineremail" name="examineremail" type="text" placeholder="" class="form-control input-md" required="">
				  </div>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="examinerdate">Date</label>  
				  <div class="col-md-5">
				  <input id="examinerdate" name="examinerdate" type="text" placeholder="" class="form-control input-md" required="">	
				  </div>
				</div>
				
			
			<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="examinertime">Time</label>  
				  <div class="col-md-5">
				  <input id="examinertime" name="examinertime" type="text" placeholder="" class="form-control input-md" required="">
				  </div>
				</div>
				

				<!-- Button -->
			<div class="form-group"  align="right" >
			  <label class="col-md-4 control-label" for="submit"></label>
			  <div class="col-md-5">
				<button id="submit" name="submit" class="btn btn-success">Add Examiner</button>
			  </div>
			</div>

			</fieldset>
			</form>
		</div>		
    </div>

<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");
   include_once("navbar.php");
?>