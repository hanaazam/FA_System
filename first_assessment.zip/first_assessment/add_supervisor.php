<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }

 $Supervisor_name = $_POST['supervisorname'];
 $Supervisor_email = $_POST['supervisoremail'];
 $Supervisor_date = $_POST['supervisordate'];
 $Supervisor_time = $_POST['supervisortime'];
 
 $sql = "INSERT INTO supervisor (Supervisor_name, Supervisor_email, Supervisor_date, Supervisor_time ) VALUES ('$Supervisor_name ', '$Supervisor_email', '$Supervisor_date', '$Supervisor_time')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else 
 {
	 echo '<script type="text/javascript">
                      alert("Supervisor added to the list");
                         location="home.php";
                           </script>';
 }


?>