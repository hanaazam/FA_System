<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }

 $Examiner_name = $_POST['examinername'];
 $Examiner_email = $_POST['examineremail'];
 $Examiner_date = $_POST['examinerdate'];
 $Examiner_time = $_POST['examinertime'];
 
 $sql = "INSERT INTO examiner (Examiner_name, Examiner_email, Examiner_date, Examiner_time) VALUES ('$Examiner_name', '$Examiner_email', $Examiner_date, $Examiner_time)";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else 
 {
	 echo '<script type="text/javascript">
                      alert("Examiner List Added");
                         location="home.php";
                           </script>';
 }


?>