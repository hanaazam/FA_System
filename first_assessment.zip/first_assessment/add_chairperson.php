<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }

 $Chairperson_name = $_POST['chairpersonname'];
 $Chairperson_email = $_POST['chairpersonemail'];
 $Chairperson_date = $_POST['chairpersondate'];
 $Chairperson_time = $_POST['chairpersontime'];

 
 $sql = "INSERT INTO  chairperson (Chairperson_name, Chairperson_email, Chairperson_date, Chairperson_time) VALUES ('$Chairperson_name', '$Chairperson_email', '$Chairperson_date', '$Chairperson_time')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else
 {
	 echo '<script type="text/javascript">
                      alert("Successfull Added");
                         location="home.php";
                           </script>';
 }
 

?>