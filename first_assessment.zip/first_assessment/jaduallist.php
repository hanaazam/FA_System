<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "header.php";
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>
body {
	background-color: white;
}
</style>
</head>
<body>
            <div align="center">
            <legend>List of Student</legend></fieldset>
			<?php
				include_once("tabletable.php");
			?>
            <?php
   include_once("footer.php");
   include_once("navbar.php");
?>