<?php 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
?>