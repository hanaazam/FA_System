<?php
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>
<style>

body {
	background-image: url();
	background-color: white;
}
th {
	text-align: center;
}
tr {
	 height: 30px;
}
td {
    padding-top: 5px;
	padding-left: 20px;	
	padding-bottom: 5px;	
	height: 20px;
}

</style>
</head>
<body><br>
<div class="container">

<body>
    <?php
     echo "<tr>
            <td>";
               // your database connection
			   $host       = "localhost"; 
               $username   = "root"; 
               $password   = "";
               $database   = "fa_db"; 
			   
               // select database
			   $conn = mysqli_connect($host,$username,$password,$database) or die(mysqli_error($conn)); 

                    $query = ("SELECT * FROM venue");
                    $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
                    echo "<div class='container'><table width='' class='table table-bordered' border='1' >
                            <tr>
                             <th>Venue</th>
                             <th>Date</th>
                             <th>Action</th>
                            </tr>";
                        while($row = mysqli_fetch_array($result))
                        {
                        echo "<tr>";
                        echo "<td>" . $row['venue_name'] . "</td>";
                        echo "<td>" . $row['venue_date'] . "</td>";
                        echo "<td><form class='form-horizontal' method='post' action='timelist.php'>
                        <input name='venue_id' type='hidden' value='".$row['venue_id']."';>
                        <input type='submit' class='btn btn-danger' name='delete' value='Delete'>
                        </form></td>";
                        echo "</tr>";
                        }
                    echo "</table>";

            echo "</td>           
        </tr>";

       // delete record
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
		
    if(isset($_POST['venue_id']))
    {
    $venue_id = mysqli_real_escape_string($conn,$_POST['venue_id']);
    $sql = mysqli_query($conn,"DELETE FROM venue WHERE venue_id='$venue_id'");
    if(!$sql)
    {
        echo ("Could not delete rows" .mysqli_error($conn));
    }else{
      echo '<script type="text/javascript">
                      alert("Successfully Deleted");
                         location="list.php";
                           </script>';
    }
	
    }
    }

    ?>
</fieldset>
</form>
</div>
</div>
</div>
</div>
	</body>
	</html>
	
<?php
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");

?>
