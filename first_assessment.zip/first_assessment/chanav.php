<?php 
 include_once("header.php");
?>

<html>
<head>
</head>

<title> POSTGRADUATE STUDENTS FIRST ASSESSMENT MANAGEMENT SYSTEM </title> 
</head>
<body>

<div class="header">
  <img src="image/logo-utm.png" alt="logo" />
  <h1>POSTGRADUATE STUDENTS FIRST ASSESSMENT MANAGEMENT SYSTEM</h1> 
<br>
<br>
<nav class="navbar">
    <div class="container-fluid">
    <div class="navbar-header">
    </div>
    <div>
	

	
    <ul class="nav navbar-nav">
        <li><a href="about.php"><span></span>About</a></li>
        <li><a href="home.php"><span></span> Set Time Table</a></li>
        <li><a href="profile.php"><span></span>Profile</a></li>
		<li><a href="addchairperson.php"><span></span> Add Chairperson</a></li>
		<li><a href="addvenue.php"><span></span>Venue</a></li>
        <li><a href="list.php"><span></span> List</a></li>
        <li><a href="tabletablelist.php"><span></span> Time Tables</a></li>
        <li><a href="index.php"><span></span>Logout</a></li>
    	</ul>
    </div>
  </div>
</nav>

</body>
</html>





