<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }
 
 $username = $_POST['username'];
 $password = $_POST['password'];
 $email = $_POST['email'];
 
 $sql = "INSERT INTO chalogin (username, password, email) VALUES ('$username', '$password', '$email')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not registered';
 }
 else 
 {
	 echo '<script type="text/javascript">
                      alert("Welcome! Your account has been created. please login to manage your schedules!");
                         location="index.php";
                           </script>';
 }


?>