<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }

 $Student_name = $_POST['studentname'];
 $Student_matric = $_POST['studentmatric'];
 $Student_email = $_POST['studentemail'];
 $Student_title = $_POST['studenttitle'];
 $Student_supervisor = $_POST['studentsupervisor'];
 $Student_venue = $_POST['studentvenue'];
 $Student_date = $_POST['studentdate'];
 $Student_time = $_POST['studenttime'];
 $Student_grade = $_POST['studentgrade'];
 
 $sql = "INSERT INTO student (Student_name, Student_matric, Student_email, Student_title, Student_supervisor, Student_venue, Student_date, Student_time, Student_grade) VALUES ('$Student_name', '$Student_matric', '$Student_email', '$Student_title',' $Student_supervisor', '$Student_venue',' $Student_date' , '$Student_time','$Student_grade')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else
 {
	 echo '<script type="text/javascript">
                      alert("Successfully added");
                         location="home.php";
                           </script>';
 }
 

?>
