<?php
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>

</head>
<body><br>
<div align="center">
			<fieldset>
            <legend>Profile</legend>
<body>
    <?php
     echo "<tr>
            <td>";
               // your database connection
			   $host       = "localhost"; 
               $username   = "root"; 
               $password   = "";
               $database   = "fa_db"; 
			   
               // select database
			   $conn = mysqli_connect($host,$username,$password,$database) or die(mysqli_error($conn)); 

                    $query = ("SELECT * FROM admin");
                    $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
                    echo "<div class='container'><table width='' class='table table-bordered' border='1' >
                            <tr>
                                
								<th>username</th>
                                <th>email</th>

                            </tr>";
                        while($row = mysqli_fetch_array($result))
                        {
                        echo "<tr>";
						echo "<td>" . $row['username'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "</tr>";
                        }
                    echo "</table>";

            echo "</td>           
        </tr>";
