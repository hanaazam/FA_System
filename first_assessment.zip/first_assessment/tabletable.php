<?php 
 
 $con = mysqli_connect ("localhost", "root", "","fa_db");
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'fa_db'))
 {
	 echo 'database not selected';
 }

 $Supervisor_name = $_POST['supervisor_name'];
 $Examiner_name = $_POST['examiner_name'];
 $Student_name = $_POST['student_name'];
 $Chairperson_name = $_POST['chairperson_name'];
 $Student_title = $_POST['student_title'];
 $Venue_name = $_POST['venue_name'];

 
 $sql = "INSERT INTO addtimetable (Student_name, Student_title, Supervisor_name, Examiner_name, Chairperson_name, Venue_name) VALUES ('$Student_name', '$Student_title', '$Supervisor_name', '$Examiner_name',' $Chairperson_name', '$Venue_name')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else
 {
	 echo '<script type="text/javascript">
                      alert("Successfully added");
                         location="home.php";
                           </script>';
 }
 

?>