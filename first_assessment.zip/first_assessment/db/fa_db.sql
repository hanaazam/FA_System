-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 10:33 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fa_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `acadmanlogin`
--

CREATE TABLE `acadmanlogin` (
  `acadmanId` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addtimetable`
--

CREATE TABLE `addtimetable` (
  `table_id` int(11) NOT NULL,
  `student_name` varchar(250) NOT NULL,
  `student_title` varchar(250) NOT NULL,
  `supervisor_name` varchar(250) NOT NULL,
  `examiner_name` varchar(250) NOT NULL,
  `chairperson_name` varchar(250) NOT NULL,
  `venue_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addtimetable`
--

INSERT INTO `addtimetable` (`table_id`, `student_name`, `student_title`, `supervisor_name`, `examiner_name`, `chairperson_name`, `venue_name`) VALUES
(1, 'Merly Syuhada Binti Megat', 'Sistem optik', 'Dr Mariani Binti Mahzan', 'Dr Abdullah Bin Kasim', ' Dr Basyir Bin Basir', 'webex'),
(6, 'Noraimi Binti Azmi', 'Sistem optik', 'Dr Mariani Binti Mahzan', 'Dr Abdullah Bin Kasim', ' Dr Basyir Bin Basir', 'webex'),
(7, 'Noraimi Binti Azmi', 'Sistem Peralihan', 'Dr Kamilah Binti Kamil', 'Dr Fadhilah Kamsah', ' Dr Basyir Bin Basir', 'Google Meet'),
(8, 'Nur Zahirah Binti Zamri', 'Sistem OrderPantas', 'Dr Mariani Binti Mahzan', 'Dr Abdullah Bin Kasim', ' Ahmad', 'Google Meet');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `username`, `password`, `email`) VALUES
(2, 'mamat', 'mamat123', 'mamat.tam@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `chairperson`
--

CREATE TABLE `chairperson` (
  `chairperson_id` int(11) NOT NULL,
  `chairperson_name` varchar(50) NOT NULL,
  `chairperson_email` varchar(50) NOT NULL,
  `chairperson_date` varchar(50) NOT NULL,
  `chairperson_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chairperson`
--

INSERT INTO `chairperson` (`chairperson_id`, `chairperson_name`, `chairperson_email`, `chairperson_date`, `chairperson_time`) VALUES
(1, 'Dr Basyir Bin Basir', 'basybasir@gmail.com', '18/09/2022', '0900'),
(2, 'Ahmad', 'Ahmad.ah@gmail.com', '20/9/2022', '0900');

-- --------------------------------------------------------

--
-- Table structure for table `chalogin`
--

CREATE TABLE `chalogin` (
  `chaId` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exalogin`
--

CREATE TABLE `exalogin` (
  `exaId` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `examiner`
--

CREATE TABLE `examiner` (
  `examiner_id` int(11) NOT NULL,
  `examiner_name` varchar(50) NOT NULL,
  `examiner_email` varchar(50) NOT NULL,
  `examiner_date` varchar(50) NOT NULL,
  `examiner_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `examiner`
--

INSERT INTO `examiner` (`examiner_id`, `examiner_name`, `examiner_email`, `examiner_date`, `examiner_time`) VALUES
(1, 'Dr Abdullah Bin Kasim', 'abdullahkas@gmail.com', '0.000989119683481701', '900'),
(2, 'Dr Fadhilah Kamsah', 'fadh.kam@gmail.com', '0.004945598417408506', '900');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `student_matric` varchar(50) NOT NULL,
  `student_email` varchar(50) NOT NULL,
  `student_title` varchar(50) NOT NULL,
  `student_supervisor` varchar(50) NOT NULL,
  `student_venue` varchar(50) NOT NULL,
  `student_date` varchar(50) NOT NULL,
  `student_time` varchar(50) NOT NULL,
  `student_grade` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_name`, `student_matric`, `student_email`, `student_title`, `student_supervisor`, `student_venue`, `student_date`, `student_time`, `student_grade`) VALUES
(1, 'Merly Syuhada Binti Megat', 'A18MT1131', 'Meryl.syu@gmail.com', 'Sistem optik', ' Dr Marina Binti Mazlan', 'Webex', ' 24/09/2022', '0900', 'N/A'),
(2, 'Noraimi Binti Azmi', 'A17CS0271', 'aimi.azmi@gmail.com', 'Sistem Peralihan', ' Dr Nor Hayati Ismail', 'Webex', ' 18/08/2022', '0900', 'N/A'),
(3, 'Nuraina syuhada Binti Mohd Haizan', 'A19SH0212', 'ainasyu@gmail,com', 'Sistem Jadual', ' Dr Marina Binti Mazlan', 'Google Meet', ' 15/09/2022', '1000', 'N/A'),
(4, 'Nur Zahirah Binti Zamri', 'A18CS0212', 'zahirah.zam@gmail.com', 'Sistem OrderPantas', ' Dr Nor Hayati Ismail', 'Webex', ' 15/09/2022', '1000', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `supervisor_id` int(11) NOT NULL,
  `supervisor_name` varchar(50) NOT NULL,
  `supervisor_email` varchar(50) NOT NULL,
  `supervisor_date` varchar(50) NOT NULL,
  `supervisor_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supervisor`
--

INSERT INTO `supervisor` (`supervisor_id`, `supervisor_name`, `supervisor_email`, `supervisor_date`, `supervisor_time`) VALUES
(1, 'Dr Mariani Binti Mahzan ', 'maria.mahzan@gmail.com', '18/09/2021', '0900'),
(2, 'Dr Kamilah Binti Kamil ', 'kamilahkam@gmail,com', '20/09.2022', '0900');

-- --------------------------------------------------------

--
-- Table structure for table `svlogin`
--

CREATE TABLE `svlogin` (
  `svId` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `venue_id` int(11) NOT NULL,
  `venue_name` varchar(50) NOT NULL,
  `venue_date` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venue_id`, `venue_name`, `venue_date`) VALUES
(3, 'webex', '18/09/2022'),
(4, 'Google Meet', '18/09/2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acadmanlogin`
--
ALTER TABLE `acadmanlogin`
  ADD PRIMARY KEY (`acadmanId`);

--
-- Indexes for table `addtimetable`
--
ALTER TABLE `addtimetable`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `chairperson`
--
ALTER TABLE `chairperson`
  ADD PRIMARY KEY (`chairperson_id`);

--
-- Indexes for table `chalogin`
--
ALTER TABLE `chalogin`
  ADD PRIMARY KEY (`chaId`);

--
-- Indexes for table `exalogin`
--
ALTER TABLE `exalogin`
  ADD PRIMARY KEY (`exaId`);

--
-- Indexes for table `examiner`
--
ALTER TABLE `examiner`
  ADD PRIMARY KEY (`examiner_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD PRIMARY KEY (`supervisor_id`);

--
-- Indexes for table `svlogin`
--
ALTER TABLE `svlogin`
  ADD PRIMARY KEY (`svId`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`venue_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acadmanlogin`
--
ALTER TABLE `acadmanlogin`
  MODIFY `acadmanId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addtimetable`
--
ALTER TABLE `addtimetable`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chairperson`
--
ALTER TABLE `chairperson`
  MODIFY `chairperson_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chalogin`
--
ALTER TABLE `chalogin`
  MODIFY `chaId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exalogin`
--
ALTER TABLE `exalogin`
  MODIFY `exaId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `examiner`
--
ALTER TABLE `examiner`
  MODIFY `examiner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `supervisor`
--
ALTER TABLE `supervisor`
  MODIFY `supervisor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `svlogin`
--
ALTER TABLE `svlogin`
  MODIFY `svId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `venue`
--
ALTER TABLE `venue`
  MODIFY `venue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
