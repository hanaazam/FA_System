<?php 
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "header.php";
   include_once("header.php");
?>
<html>
<head>
<style>
body, html {
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
  
}
body{
    background:linear-gradient(to bottom,  #ff5050 0%, #990000 100%);
}
form { border : 2px solid #141011;}

* { box-sizing: border-box;}

.header {
    padding : 40 px;
    font-style:unset;
    text-align: center;
    color:white;
    font-size:15px;
}
.center{
    margin-left:auto;
    margin-right:auto;
    font-style:inherit;
    text-align: center;
    width: 50%;
    padding:10px;
}

/* Add styles to the form container */
.container {
  margin: auto;
  text-align: center;
  max-width: 600px;
  padding: 50px;
  background-color: white;
}

.form_login
{
    left:50%;
    top: 50%;
    position: absolute;
    transform: translate ( -50%, -50%);

}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.btn {
  background-color: #660000;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
<title>Login Page</title>
</head>
 
<body>
    <br>
    <br>
<div class="header"> <h1><b> POSTGRADUATE STUDENTS FIRST ASSESSMENT MANAGEMENT SYSTEM </b></h1></div><br>
<div class="center">
<div class="center"></div>
  
  <form class="container" class="center">
  <img src="image/logo-utm.png" height=140px width=70%><br><br>
  <h1 class="center">LOGIN</h1><br>
    
  <br><a class="btn" href="aosindex.php">Academic Office Staff</a>
  <br>
  <br><a class="btn" href="academicmanagerindex.php">Academic Manager</a>
  <br>
  <br><a class="btn" href="supervisorindex.php">Supervisor</a>
  <br> 
  <br><a class="btn" href="examinerindex.php">Examiner</a>
  <br>
  <br><a class="btn" href="chairpersonindex.php">Chairperson</a>
  <br><br>
		</div>
	</div>
</body>
</html>

<?php 
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");
?>
