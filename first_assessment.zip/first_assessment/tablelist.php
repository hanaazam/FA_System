<?php
   include_once("header.php");
   include_once("navbar.php");
?>
<html>
<head>

</head>
<body><br>
<div align="center">
			<fieldset>
            <legend>First Assessment Time Table</legend>
<body>
    <?php
     echo "<tr>
            <td>";
               // your database connection
			   $host       = "localhost"; 
               $username   = "root"; 
               $password   = "";
               $database   = "fa_db"; 
			   
               // select database
			   $conn = mysqli_connect($host,$username,$password,$database) or die(mysqli_error($conn)); 

                    $query = ("SELECT * FROM addtimetable");
                    $result = mysqli_query($conn,$query) or die(mysqli_error($conn));
                    echo "<div class='container'><table width='' class='table table-bordered' border='1' >
                            <tr>
                                <th>Student</th>
								<th>Title</th>
                                <th>Supervisor</th>
								<th>Examiner</th>
								<th>Chairperson</th>
								<th>Venue</th>
                                <th>Action</th>
                            </tr>";
                        while($row = mysqli_fetch_array($result))
                        {
                        echo "<tr>";
                        echo "<td>" . $row['student_name'] . "</td>";
						echo "<td>" . $row['student_title'] . "</td>";
                        echo "<td>" . $row['supervisor_name'] . "</td>";
						echo "<td>" . $row['examiner_name'] . "</td>";
						echo "<td>" . $row['chairperson_name'] . "</td>";
						echo "<td>" . $row['venue_name'] . "</td>";
                        echo "<td><form class='form-horizontal' method='post' action='tablelist.php'>
                        <input name='table_id' type='hidden' value='".$row['table_id']."';>
                        <input type='submit' class='btn btn-danger' name='delete' value='Delete'>
                        </form></td>";
                        echo "</tr>";
                        }
                    echo "</table>";

            echo "</td>           
        </tr>";

       // delete record
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
		
    if(isset($_POST['table_id']))
    {
    $table_id = mysqli_real_escape_string($conn,$_POST['table_id']);
    $sql = mysqli_query($conn,"DELETE FROM addtimetable WHERE table_id='$table_id'");
    if(!$sql)
    {
        echo ("Could not delete rows" .mysqli_error($conn));
    }else{
      echo '<script type="text/javascript">
                      alert("Schedule Successfully Deleted");
                         location="tablelist.php";
                           </script>';
    }
	
    }
    }

    ?>
</fieldset>
</form>
</div>
</div>
</div>

<div align="center">
<br>
<a href="Index.php"><input type='submit' class='btn btn-danger' name='delete' value='Logout'></a>
</div>
</div>
	</body>
	</html>
	
<?php
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");

?>
